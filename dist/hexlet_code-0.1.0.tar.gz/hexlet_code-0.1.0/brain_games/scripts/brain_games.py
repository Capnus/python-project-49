#!/usr/bin/env python3

def greet():
    return 'Welcome to the Brain Games!'

def main():
    print(greet())

if __name__ == '__main__':
    main()

