#!/usr/bin/env python3
from random import randint
from brain_games.cli import welcome_user
from brain_games import greet


def brain_even():
    print('Answer "yes"  if the number is even, otherwise answer "no".')
    count_correct_answer = 0
    while count_correct_answer != 3:
        number = randint(1, 100)
        print('Question: ', number)
        answer = input()
        print('Your answer: ', answer)
        if number % 2 == 0:
            if answer == 'yes':
                print('Correct!')
                count_correct_answer += 1
            if answer != 'yes':
                return print(f"'{answer}' is wrong answer ;(. Correct answer was 'yes'." )
        elif number % 2 != 0:
            if answer == 'no':
                print('Correct!')
                count_correct_answer += 1
            if answer != 'no':
                return print(f"'{answer}' is wrong answer ;(. Correct answer was 'no'." )
                
    print(f'Congratulations, {name}')


def main():
    greet()
    welcome_user()
    brain_even()


if __name__ == '__main__':
    main()
